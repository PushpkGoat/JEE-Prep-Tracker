import React, { useState, useRef, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Slider,
  IconButton,
  Button,
  Grid,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Switch,
  FormControlLabel,
  Tooltip,
  Tabs,
  Tab,
  Snackbar,
  Alert,
} from '@mui/material';
import {
  PlayArrow,
  Pause,
  VolumeUp,
  VolumeOff,
  SkipNext,
  SkipPrevious,
  Fullscreen,
  FullscreenExit,
  PictureInPicture,
  Speed,
  DoNotDisturb,
  Bookmark,
  Add,
  Delete,
  Edit,
  Folder,
  VideoLibrary,
  AccessTime,
} from '@mui/icons-material';

// Define interfaces
interface VideoFile {
  id: string;
  title: string;
  path: string;
  duration: number;
  thumbnail: string;
  tags: string[];
  category: string;
  lastPlayed: string | null;
  progress: number;
  favorite: boolean;
}

interface Category {
  id: string;
  name: string;
}

const VideoPlayer: React.FC = () => {
  // Video player state
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.5);
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [pip, setPip] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [dndMode, setDndMode] = useState(false);
  const [timeStretchEnabled, setTimeStretchEnabled] = useState(true);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  
  // Video library state
  const [videos, setVideos] = useState<VideoFile[]>([
    {
      id: 'video-1',
      title: 'JEE Physics - Mechanics Lecture 1',
      path: 'https://example.com/video1.mp4',
      duration: 1800, // 30 minutes
      thumbnail: 'https://source.unsplash.com/random/300x200?physics&sig=1',
      tags: ['physics', 'mechanics', 'jee'],
      category: 'Physics',
      lastPlayed: '2023-11-01',
      progress: 0.7,
      favorite: true
    },
    {
      id: 'video-2',
      title: 'JEE Chemistry - Organic Chemistry Basics',
      path: 'https://example.com/video2.mp4',
      duration: 2400, // 40 minutes
      thumbnail: 'https://source.unsplash.com/random/300x200?chemistry&sig=2',
      tags: ['chemistry', 'organic', 'jee'],
      category: 'Chemistry',
      lastPlayed: '2023-11-02',
      progress: 0.3,
      favorite: false
    },
    {
      id: 'video-3',
      title: 'JEE Mathematics - Calculus Introduction',
      path: 'https://example.com/video3.mp4',
      duration: 3000, // 50 minutes
      thumbnail: 'https://source.unsplash.com/random/300x200?mathematics&sig=3',
      tags: ['mathematics', 'calculus', 'jee'],
      category: 'Mathematics',
      lastPlayed: '2023-11-03',
      progress: 0.1,
      favorite: true
    }
  ]);
  
  const [categories, setCategories] = useState<Category[]>([
    { id: 'cat-1', name: 'Physics' },
    { id: 'cat-2', name: 'Chemistry' },
    { id: 'cat-3', name: 'Mathematics' }
  ]);
  
  const [currentVideo, setCurrentVideo] = useState<VideoFile | null>(null);
  const [currentTab, setCurrentTab] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newVideoTitle, setNewVideoTitle] = useState('');
  const [newVideoCategory, setNewVideoCategory] = useState('');
  const [newVideoTags, setNewVideoTags] = useState<string[]>([]);
  const [newTagInput, setNewTagInput] = useState('');
  const [editingVideo, setEditingVideo] = useState<VideoFile | null>(null);
  
  // Refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const videoContainerRef = useRef<HTMLDivElement>(null);
  
  // Load data from storage on component mount
  useEffect(() => {
    const loadVideoLibrary = async () => {
      try {
        // In a real app, this would call the Electron backend
        // const videoLibrary = await window.electron.ipcRenderer.invoke('get-video-library');
        // if (videoLibrary) {
        //   setVideos(videoLibrary.videos || []);
        //   setCategories(videoLibrary.categories || []);
        // }
      } catch (error) {
        console.error('Failed to load video library:', error);
      }
    };

    loadVideoLibrary();
  }, []);

  // Save data to storage when it changes
  useEffect(() => {
    const saveVideoLibrary = async () => {
      try {
        // In a real app, this would call the Electron backend
        // await window.electron.ipcRenderer.invoke('save-video-library', { videos, categories });
      } catch (error) {
        console.error('Failed to save video library:', error);
      }
    };

    saveVideoLibrary();
  }, [videos, categories]);

  // Handle video time update
  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;

    const handleTimeUpdate = () => {
      setCurrentTime(videoElement.currentTime);
      
      // Update video progress
      if (currentVideo && videoElement.duration > 0) {
        const progress = videoElement.currentTime / videoElement.duration;
        
        setVideos(prevVideos => 
          prevVideos.map(video => 
            video.id === currentVideo.id 
              ? { ...video, progress, lastPlayed: new Date().toISOString().split('T')[0] } 
              : video
          )
        );
      }
    };

    const handleLoadedMetadata = () => {
      setDuration(videoElement.duration);
    };

    videoElement.addEventListener('timeupdate', handleTimeUpdate);
    videoElement.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      videoElement.removeEventListener('timeupdate', handleTimeUpdate);
      videoElement.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [currentVideo]);

  // Handle Do Not Disturb mode
  useEffect(() => {
    const toggleDND = async () => {
      try {
        if (dndMode) {
          // In a real app, this would call the Electron backend
          await window.electron.ipcRenderer.invoke('enable-dnd');
          setSnackbarMessage('Do Not Disturb mode enabled');
          setSnackbarOpen(true);
        } else {
          await window.electron.ipcRenderer.invoke('disable-dnd');
          setSnackbarMessage('Do Not Disturb mode disabled');
          setSnackbarOpen(true);
        }
      } catch (error) {
        console.error('Failed to toggle DND mode:', error);
      }
    };

    toggleDND();
  }, [dndMode]);

  // Apply time stretch effect
  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;
    
    // In a real implementation, this would use the Web Audio API to apply time stretching
    // without changing pitch. For this demo, we'll just set a property to indicate the feature is enabled.
    if (videoElement.preservesPitch !== undefined) {
      videoElement.preservesPitch = timeStretchEnabled;
    }
  }, [timeStretchEnabled]);

  // Format seconds to HH:MM:SS
  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return [
      hours > 0 ? String(hours).padStart(2, '0') : null,
      String(minutes).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].filter(Boolean).join(':');
  };

  // Calculate time remaining based on playback rate
  const calculateTimeRemaining = (): string => {
    if (!videoRef.current) return '00:00';
    
    const timeRemaining = (duration - currentTime) / playbackRate;
    return formatTime(timeRemaining);
  };

  // Play/pause video
  const togglePlay = () => {
    if (!videoRef.current || !currentVideo) return;
    
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    
    setPlaying(!playing);
  };

  // Toggle mute
  const toggleMute = () => {
    if (!videoRef.current) return;
    
    videoRef.current.muted = !muted;
    setMuted(!muted);
  };

  // Change volume
  const handleVolumeChange = (event: Event, newValue: number | number[]) => {
    const newVolume = newValue as number;
    setVolume(newVolume);
    
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
    }
    
    if (newVolume === 0) {
      setMuted(true);
    } else if (muted) {
      setMuted(false);
    }
  };

  // Seek video
  const handleSeek = (event: Event, newValue: number | number[]) => {
    const newTime = newValue as number;
    setCurrentTime(newTime);
    
    if (videoRef.current) {
      videoRef.current.currentTime = newTime;
    }
  };

  // Change playback rate
  const handlePlaybackRateChange = (rate: number) => {
    setPlaybackRate(rate);
    
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
    
    setSnackbarMessage(`Playback speed set to ${rate}x`);
    setSnackbarOpen(true);
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!videoContainerRef.current) return;
    
    if (!fullscreen) {
      if (videoContainerRef.current.requestFullscreen) {
        videoContainerRef.current.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
    
    setFullscreen(!fullscreen);
  };

  // Toggle picture-in-picture
  const togglePip = async () => {
    if (!videoRef.current) return;
    
    try {
      if (!pip) {
        await videoRef.current.requestPictureInPicture();
      } else {
        if (document.exitPictureInPicture) {
          await document.exitPictureInPicture();
        }
      }
      
      setPip(!pip);
    } catch (error) {
      console.error('Failed to toggle PiP:', error);
    }
  };

  // Play video
  const playVideo = (video: VideoFile) => {
    setCurrentVideo(video);
    setPlaying(true);
    
    // In a real implementation, this would set the video source
    if (videoRef.current) {
      videoRef.current.src = video.path;
      videoRef.current.currentTime = video.progress * video.duration;
      videoRef.current.play().catch(err => {
        console.error('Failed to play video:', err);
      });
    }
  };

  // Skip to next video
  const playNextVideo = () => {
    if (!currentVideo) return;
    
    const currentIndex = videos.findIndex(v => v.id === currentVideo.id);
    if (currentIndex < videos.length - 1) {
      playVideo(videos[currentIndex + 1]);
    }
  };

  // Skip to previous video
  const playPreviousVideo = () => {
    if (!currentVideo) return;
    
    const currentIndex = videos.findIndex(v => v.id === currentVideo.id);
    if (currentIndex > 0) {
      playVideo(videos[currentIndex - 1]);
    }
  };

  // Toggle favorite
  const toggleFavorite = (videoId: string) => {
    setVideos(prevVideos => 
      prevVideos.map(video => 
        video.id === videoId 
          ? { ...video, favorite: !video.favorite } 
          : video
      )
    );
  };

  // Handle tab change
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setCurrentTab(newValue);
  };

  // Open add/edit video dialog
  const handleOpenDialog = (video?: VideoFile) => {
    if (video) {
      setEditingVideo(video);
      setNewVideoTitle(video.title);
      setNewVideoCategory(video.category);
      setNewVideoTags(video.tags);
    } else {
      setEditingVideo(null);
      setNewVideoTitle('');
      setNewVideoCategory(categories[0]?.name || '');
      setNewVideoTags([]);
    }
    
    setDialogOpen(true);
  };

  // Add tag to new video
  const handleAddTag = () => {
    if (!newTagInput.trim()) return;
    
    if (!newVideoTags. includes(newTagInput.trim())) {
      setNewVideoTags([...newVideoTags, newTagInput.trim()]);
    }
    
    setNewTagInput('');
  };

  // Remove tag from new video
  const handleRemoveTag = (tag: string) => {
    setNewVideoTags(newVideoTags.filter(t => t !== tag));
  };

  // Save new/edited video
  const handleSaveVideo = () => {
    if (!newVideoTitle.trim() || !newVideoCategory.trim()) {
      return;
    }

    if (editingVideo) {
      // Edit existing video
      setVideos(prevVideos => 
        prevVideos.map(video => 
          video.id === editingVideo.id 
            ? { 
                ...video, 
                title: newVideoTitle,
                category: newVideoCategory,
                tags: newVideoTags
              } 
            : video
        )
      );
    } else {
      // Add new video (in a real app, this would open a file dialog)
      const newVideo: VideoFile = {
        id: `video-${Date.now()}`,
        title: newVideoTitle,
        path: 'https://example.com/new-video.mp4',
        duration: 1800, // 30 minutes
        thumbnail: `https://source.unsplash.com/random/300x200?${newVideoCategory.toLowerCase()}&sig=${Date.now()}`,
        tags: newVideoTags,
        category: newVideoCategory,
        lastPlayed: null,
        progress: 0,
        favorite: false
      };
      
      setVideos([...videos, newVideo]);
    }

    setDialogOpen(false);
  };

  // Delete video
  const handleDeleteVideo = (videoId: string) => {
    setVideos(prevVideos => prevVideos.filter(video => video.id !== videoId));
    
    if (currentVideo?.id === videoId) {
      setCurrentVideo(null);
      setPlaying(false);
    }
  };

  // Filter videos based on current tab
  const getFilteredVideos = () => {
    switch (currentTab) {
      case 0: // All
        return videos;
      case 1: // Favorites
        return videos.filter(video => video.favorite);
      case 2: // In Progress
        return videos.filter(video => video.progress > 0 && video.progress < 0.95);
      case 3: // Completed
        return videos.filter(video => video.progress >= 0.95);
      default:
        return videos;
    }
  };

  // Create stars for galaxy theme
  useEffect(() => {
    const starsContainer = document.createElement('div');
    starsContainer.className = 'stars-container';
    document.body.appendChild(starsContainer);
    
    // Create galaxy background
    const galaxyBg = document.createElement('div');
    galaxyBg.className = 'galaxy-bg';
    document.body.appendChild(galaxyBg);
    
    // Create stars
    for (let i = 0; i < 100; i++) {
      const star = document.createElement('div');
      star.className = 'star';
      star.style.width = `${Math.random() * 3 + 1}px`;
      star.style.height = star.style.width;
      star.style.left = `${Math.random() * 100}%`;
      star.style.top = `${Math.random() * 100}%`;
      star.style.setProperty('--duration', `${Math.random() * 3 + 2}s`);
      star.style.setProperty('--opacity', `${Math.random() * 0.7 + 0.3}`);
      starsContainer.appendChild(star);
    }
    
    // Create floating particles
    for (let i = 0; i < 30; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      particle.style.animationDelay = `${Math.random() * 15}s`;
      starsContainer.appendChild(particle);
    }
    
    return () => {
      document.body.removeChild(starsContainer);
      document.body.removeChild(galaxyBg);
    };
  }, []);

  return (
    <Box>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper elevation={3} sx={{ mb: 3 }}>
            <Box 
              ref={videoContainerRef}
              sx={{ 
                position: 'relative',
                backgroundColor: '#000',
                aspectRatio: '16/9',
                overflow: 'hidden'
              }}
            >
              {currentVideo ? (
                <video
                  ref={videoRef}
                  style={{ width: '100%', height: '100%' }}
                  onPlay={() => setPlaying(true)}
                  onPause={() => setPlaying(false)}
                  onEnded={() => {
                    setPlaying(false);
                    playNextVideo();
                  }}
                />
              ) : (
                <Box 
                  sx={{ 
                    display: 'flex', 
                    flexDirection: 'column',
                    alignItems: 'center', 
                    justifyContent: 'center',
                    height: '100%',
                    color: 'rgba(255,255,255,0.7)'
                  }}
                >
                  <VideoLibrary sx={{ fontSize: 60, mb: 2 }} />
                  <Typography variant="h6">
                    Select a video to play
                  </Typography>
                </Box>
              )}
              
              {/* Video controls overlay */}
              <Box 
                sx={{ 
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  padding: 2,
                  background: 'linear-gradient(transparent, rgba(0,0,0,0.7))',
                  transition: 'opacity 0.3s',
                  opacity: 1,
                  '&:hover': {
                    opacity: 1
                  }
                }}
              >
                {/* Playback speed controls at top */}
                <Box 
                  sx={{ 
                    position: 'absolute',
                    top: -50,
                    left: 0,
                    right: 0,
                    padding: '8px 16px',
                    background: 'rgba(0,0,0,0.7)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderTopLeftRadius: 8,
                    borderTopRightRadius: 8,
                  }}
                >
                  <Typography variant="body2" sx={{ mr: 2 }}>
                    <Speed fontSize="small" sx={{ verticalAlign: 'middle', mr: 0.5 }} />
                    Speed:
                  </Typography>
                  
                  <Slider
                    value={playbackRate}
                    min={0.25}
                    max={3}
                    step={0.25}
                    marks={[
                      { value: 0.5, label: '0.5x' },
                      { value: 1, label: '1x' },
                      { value: 1.5, label: '1.5x' },
                      { value: 2, label: '2x' },
                      { value: 2.5, label: '2.5x' },
                    ]}
                    onChange={(_, value) => handlePlaybackRateChange(value as number)}
                    sx={{ 
                      width: '60%',
                      mx: 2,
                      '& .MuiSlider-markLabel': {
                        color: 'rgba(255,255,255,0.7)',
                      }
                    }}
                  />
                  
                  <Typography variant="body2" sx={{ ml: 2, minWidth: 40 }}>
                    {playbackRate}x
                  </Typography>
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Slider
                    value={currentTime}
                    min={0}
                    max={duration || 100}
                    onChange={handleSeek}
                    sx={{ 
                      mx: 2,
                      '& .MuiSlider-thumb': {
                        width: 12,
                        height: 12,
                      }
                    }}
                  />
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <IconButton onClick={playPreviousVideo} color="inherit" size="small">
                      <SkipPrevious />
                    </IconButton>
                    
                    <IconButton onClick={togglePlay} color="inherit">
                      {playing ? <Pause /> : <PlayArrow />}
                    </IconButton>
                    
                    <IconButton onClick={playNextVideo} color="inherit" size="small">
                      <SkipNext />
                    </IconButton>
                    
                    <IconButton onClick={toggleMute} color="inherit" size="small">
                      {muted ? <VolumeOff /> : <VolumeUp />}
                    </IconButton>
                    
                    <Box sx={{ width: 100, mx: 1 }}>
                      <Slider
                        value={volume}
                        min={0}
                        max={1}
                        step={0.01}
                        onChange={handleVolumeChange}
                        size="small"
                      />
                    </Box>
                    
                    <Typography variant="body2" sx={{ mx: 1, minWidth: 80 }}>
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Chip 
                      icon={<AccessTime sx={{ fontSize: '0.75rem !important' }} />}
                      label={`${calculateTimeRemaining()} remaining`}
                      size="small"
                      sx={{ mr: 1, backgroundColor: 'rgba(0,0,0,0.5)' }}
                    />
                    
                    <Tooltip title="Picture in Picture">
                      <IconButton onClick={togglePip} color="inherit" size="small">
                        <PictureInPicture />
                      </IconButton>
                    </Tooltip>
                    
                    <Tooltip title="Fullscreen">
                      <IconButton onClick={toggleFullscreen} color="inherit" size="small">
                        {fullscreen ? <FullscreenExit /> : <Fullscreen />}
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              </Box>
            </Box>
            
            {currentVideo && (
              <Box sx={{ p: 2 }}>
                <Typography variant="h6">{currentVideo.title}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                  <Chip 
                    label={currentVideo.category} 
                    size="small" 
                    sx={{ mr: 1 }}
                  />
                  {currentVideo.tags.map(tag => (
                    <Chip 
                      key={tag} 
                      label={tag} 
                      size="small" 
                      variant="outlined" 
                      sx={{ mr: 1 }}
                    />
                  ))}
                </Box>
              </Box>
            )}
          </Paper>
          
          <Paper elevation={3} sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Advanced Settings
              </Typography>
              <FormControlLabel
                control={
                  <Switch 
                    checked={dndMode}
                    onChange={() => setDndMode(!dndMode)}
                    color="primary"
                  />
                }
                label={
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <DoNotDisturb sx={{ mr: 1 }} />
                    Do Not Disturb Mode
                  </Box>
                }
              />
            </Box>
            
            <Typography variant="body2" color="textSecondary" paragraph>
              Do Not Disturb mode prevents other applications from interrupting your study session by blocking notifications and keeping the video player in focus.
            </Typography>
            
            <Divider sx={{ my: 2 }} />
            
            <FormControlLabel
              control={
                <Switch 
                  checked={timeStretchEnabled}
                  onChange={() => setTimeStretchEnabled(!timeStretchEnabled)}
                  color="primary"
                />
              }
              label={
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Speed sx={{ mr: 1 }} />
                  Time Stretch (Preserve Pitch)
                </Box>
              }
            />
            
            <Typography variant="body2" color="textSecondary">
              Time stretching allows you to change playback speed without affecting the pitch of voices, making lectures easier to understand at higher speeds.
            </Typography>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ mb: 3 }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs value={currentTab} onChange={handleTabChange}>
                <Tab label="All" />
                <Tab label="Favorites" />
                <Tab label="In Progress" />
                <Tab label="Completed" />
              </Tabs>
            </Box>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2 }}>
              <Typography variant="subtitle1">
                Video Library
              </Typography>
              <Button 
                variant="contained" 
                size="small"
                startIcon={<Add />}
                onClick={() => handleOpenDialog()}
              >
                Add Video
              </Button>
            </Box>
            
            <List sx={{ maxHeight: 500, overflow: 'auto' }}>
              {getFilteredVideos().map((video) => (
                <React.Fragment key={video.id}>
                  <ListItem 
                    sx={{ 
                      cursor: 'pointer',
                      bgcolor: currentVideo?.id === video.id ? 'rgba(63, 81, 181, 0.1)' : 'transparent'
                    }}
                    onClick={() => playVideo(video)}
                  >
                    <Box sx={{ display: 'flex', width: '100%', alignItems: 'center' }}>
                      <Box 
                        sx={{ 
                          width: 100, 
                          height: 56, 
                          mr: 2, 
                          position: 'relative',
                          borderRadius: 1,
                          overflow: 'hidden'
                        }}
                      >
                        <img 
                          src={video.thumbnail} 
                          alt={video.title}
                          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        />
                        {video.progress > 0 && (
                          <Box 
                            sx={{ 
                              position: 'absolute', 
                              bottom: 0, 
                              left: 0, 
                              right: 0, 
                              height: 3, 
                              bgcolor: 'primary.main' 
                            }}
                            style={{ width: `${video.progress * 100}%` }}
                          />
                        )}
                      </Box>
                      
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography variant="body1" noWrap>
                          {video.title}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          {formatTime(video.duration)}
                        </Typography>
                        <Box sx={{ display: 'flex', mt: 0.5 }}>
                          <Chip 
                            label={video.category} 
                            size="small" 
                            sx={{ mr: 1, height: 20, fontSize: '0.625rem' }}
                          />
                          {video.favorite && (
                            <Chip 
                              icon={<Bookmark sx={{ fontSize: '0.75rem !important' }} />}
                              label="Favorite" 
                              size="small" 
                              color="secondary"
                              sx={{ height: 20, fontSize: '0.625rem' }}
                            />
                          )}
                        </Box>
                      </Box>
                      
                      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                        <IconButton 
                          size="small" 
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(video.id);
                          }}
                        >
                          <Bookmark color={video.favorite ? 'secondary' : 'action'} />
                        </IconButton>
                        <IconButton 
                          size="small" 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenDialog(video);
                          }}
                        >
                          <Edit />
                        </IconButton>
                      </Box>
                    </Box>
                  </ListItem>
                  <Divider />
                </React.Fragment>
              ))}
              
              {getFilteredVideos().length === 0 && (
                <Box sx={{ p: 3, textAlign: 'center' }}>
                  <Typography variant="body1" color="textSecondary">
                    No videos found in this category.
                  </Typography>
                </Box>
              )}
            </List>
          </Paper>
          
          <Paper elevation={3} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Categories
            </Typography>
            <List dense>
              {categories.map((category) => (
                <ListItem key={category.id}>
                  <ListItemIcon>
                    <Folder />
                  </ListItemIcon>
                  <ListItemText 
                    primary={category.name} 
                    secondary={`${videos.filter(v => v.category === category.name).length} videos`}
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Add/Edit Video Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>{editingVideo ? 'Edit Video' : 'Add New Video'}</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Video Title"
            fullWidth
            value={newVideoTitle}
            onChange={(e) => setNewVideoTitle(e.target.value)}
            sx={{ mb: 2 }}
          />
          
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Category</InputLabel>
            <Select
              value={newVideoCategory}
              label="Category"
              onChange={(e) => setNewVideoCategory(e.target.value)}
            >
              {categories.map((category) => (
                <MenuItem key={category.id} value={category.name}>
                  {category.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Tags
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
              {newVideoTags.map((tag) => (
                <Chip 
                  key={tag} 
                  label={tag} 
                  onDelete={() => handleRemoveTag(tag)}
                  size="small"
                />
              ))}
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <TextField
                size="small"
                label="Add Tag"
                value={newTagInput}
                onChange={(e) => setNewTagInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleAddTag();
                    e.preventDefault();
                  }
                }}
              />
              <Button 
                variant="outlined" 
                onClick={handleAddTag}
              >
                Add
              </Button>
            </Box>
          </Box>
          
          {!editingVideo && (
            <Typography variant="body2" color="textSecondary">
              In a real application, this would open a file dialog to select a video file.
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          {editingVideo && (
            <Button 
              onClick={() => {
                handleDeleteVideo(editingVideo.id);
                setDialogOpen(false);
              }} 
              color="error"
            >
              Delete
            </Button>
          )}
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveVideo} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
      
      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={4000}
        onClose={() => setSnackbarOpen(false)}
      >
        <Alert severity="info" sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default VideoPlayer;