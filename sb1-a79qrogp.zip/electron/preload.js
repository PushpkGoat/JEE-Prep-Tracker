const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electron', {
  ipcRenderer: {
    // Send methods
    send: (channel, data) => {
      // Whitelist channels
      const validChannels = [
        'update-settings',
        'download-video',
        'fetch-playlist',
        'save-study-plan',
        'save-video-library'
      ];
      if (validChannels.includes(channel)) {
        ipcRenderer.send(channel, data);
      }
    },
    
    // Invoke methods (async)
    invoke: (channel, data) => {
      const validChannels = [
        'rotate-ip',
        'fetch-playlist',
        'download-video',
        'update-settings',
        'get-settings',
        'select-download-directory',
        'enable-dnd',
        'disable-dnd',
        'open-file',
        'save-study-plan',
        'get-study-plan',
        'save-video-library',
        'get-video-library'
      ];
      if (validChannels.includes(channel)) {
        return ipcRenderer.invoke(channel, data);
      }
      
      return Promise.reject(new Error(`Invalid channel: ${channel}`));
    },
    
    // Receive methods
    on: (channel, func) => {
      const validChannels = [
        'download-progress',
        'download-complete',
        'proxy-rotated'
      ];
      if (validChannels.includes(channel)) {
        // Deliberately strip event as it includes `sender` 
        ipcRenderer.on(channel, (event, ...args) => func(...args));
      }
    },
    
    // Remove listener
    removeListener: (channel, func) => {
      const validChannels = [
        'download-progress',
        'download-complete',
        'proxy-rotated'
      ];
      if (validChannels.includes(channel)) {
        ipcRenderer.removeListener(channel, func);
      }
    }
  }
});