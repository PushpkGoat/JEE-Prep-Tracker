import React, { useState } from 'react';
import { 
  Box, 
  TextField, 
  Button, 
  Typography, 
  Paper, 
  CircularProgress, 
  List, 
  ListItem, 
  ListItemText, 
  Divider,
  Card,
  CardContent,
  Grid,
  Chip
} from '@mui/material';
import { PlayCircle, AccessTime, VideoLibrary } from '@mui/icons-material';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

// Define interfaces
interface Video {
  id: string;
  title: string;
  thumbnail: string;
  duration: number;
}

interface Playlist {
  id: string;
  title: string;
  videos: Video[];
}

const PlaylistCalculator: React.FC = () => {
  const [url, setUrl] = useState<string>('');
  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Calculate total duration in seconds
  const getTotalDuration = (): number => {
    if (!playlist) return 0;
    return playlist.videos.reduce((total, video) => total + video.duration, 0);
  };

  // Format seconds to HH:MM:SS
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return [
      hours > 0 ? String(hours).padStart(2, '0') : null,
      String(minutes).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].filter(Boolean).join(':');
  };

  // Calculate watch time at different speeds
  const getWatchTimeAtSpeed = (speed: number): string => {
    const totalSeconds = getTotalDuration();
    return formatDuration(totalSeconds / speed);
  };

  // Fetch playlist data
  const fetchPlaylist = async () => {
    if (!url) {
      setError('Please enter a YouTube playlist URL');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would call the Electron backend
      // For now, we'll simulate the response
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock playlist data
      const mockPlaylist: Playlist = {
        id: 'playlist-' + Date.now(),
        title: 'JEE Physics Complete Course',
        videos: Array(15).fill(null).map((_, i) => ({
          id: `video-${i}`,
          title: `${i+1}. ${['Mechanics', 'Electromagnetism', 'Optics', 'Modern Physics', 'Thermodynamics'][i % 5]} - Lecture ${Math.floor(i/5) + 1}`,
          thumbnail: `https://source.unsplash.com/random/300x200?science&sig=${i}`,
          duration: 600 + (i * 120) // 10 minutes + i * 2 minutes
        }))
      };
      
      setPlaylist(mockPlaylist);
      setLoading(false);
    } catch (err) {
      console.error('Failed to fetch playlist:', err);
      setError('Failed to fetch playlist. Please check the URL and try again.');
      setLoading(false);
    }
  };

  // Prepare chart data
  const getPieChartData = () => {
    if (!playlist) return null;
    
    // Group videos by category (first word of title after the number)
    const categories: {[key: string]: number} = {};
    
    playlist.videos.forEach(video => {
      const match = video.title.match(/^\d+\.\s([A-Za-z]+)/);
      const category = match ? match[1] : 'Other';
      
      if (categories[category]) {
        categories[category] += video.duration;
      } else {
        categories[category] = video.duration;
      }
    });
    
    return {
      labels: Object.keys(categories),
      datasets: [
        {
          data: Object.values(categories),
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56',
            '#4BC0C0',
            '#9966FF',
            '#FF9F40'
          ],
          borderWidth: 1,
        },
      ],
    };
  };

  const getBarChartData = () => {
    if (!playlist) return null;
    
    return {
      labels: ['0.5x', '0.75x', '1x', '1.25x', '1.5x', '1.75x', '2x'],
      datasets: [
        {
          label: 'Watch Time (minutes)',
          data: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map(
            speed => getTotalDuration() / speed / 60
          ),
          backgroundColor: 'rgba(54, 162, 235, 0.5)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1,
        },
      ],
    };
  };

  return (
    <Box>
      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Enter YouTube Playlist URL
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="https://www.youtube.com/playlist?list=..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            error={!!error}
            helperText={error}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={fetchPlaylist}
            disabled={loading}
            startIcon={loading ? <CircularProgress size={20} /> : <PlayCircle />}
          >
            {loading ? 'Loading...' : 'Calculate'}
          </Button>
        </Box>
      </Paper>

      {playlist && (
        <>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={4}>
              <Card elevation={3}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <VideoLibrary sx={{ mr: 1 }} />
                    <Typography variant="h6">Videos</Typography>
                  </Box>
                  <Typography variant="h3" align="center">
                    {playlist.videos.length}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card elevation={3}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <AccessTime sx={{ mr: 1 }} />
                    <Typography variant="h6">Total Duration</Typography>
                  </Box>
                  <Typography variant="h3" align="center">
                    {formatDuration(getTotalDuration())}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card elevation={3}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Watch Time at 2x Speed
                  </Typography>
                  <Typography variant="h3" align="center">
                    {getWatchTimeAtSpeed(2)}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" align="center">
                    Save {formatDuration(getTotalDuration() - getTotalDuration()/2)} of time
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 3, height: '100%' }}>
                <Typography variant="h6" gutterBottom>
                  Content Breakdown
                </Typography>
                {getPieChartData() && (
                  <Box sx={{ height: 300 }}>
                    <Pie data={getPieChartData()!} options={{ maintainAspectRatio: false }} />
                  </Box>
                )}
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 3, height: '100%' }}>
                <Typography variant="h6" gutterBottom>
                  Watch Time by Playback Speed
                </Typography>
                {getBarChartData() && (
                  <Box sx={{ height: 300 }}>
                    <Bar 
                      data={getBarChartData()!} 
                      options={{ 
                        maintainAspectRatio: false,
                        scales: {
                          y: {
                            title: {
                              display: true,
                              text: 'Minutes'
                            }
                          }
                        }
                      }} 
                    />
                  </Box>
                )}
              </Paper>
            </Grid>
          </Grid>

          <Paper elevation={3} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Video List
            </Typography>
            <List>
              {playlist.videos.map((video, index) => (
                <React.Fragment key={video.id}>
                  {index > 0 && <Divider />}
                  <ListItem>
                    <ListItemText
                      primary={video.title}
                      secondary={
                        <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                          <AccessTime fontSize="small" sx={{ mr: 0.5 }} />
                          <Typography variant="body2" component="span">
                            {formatDuration(video.duration)}
                          </Typography>
                          <Chip 
                            label={`${(video.duration / getTotalDuration() * 100).toFixed(1)}%`} 
                            size="small" 
                            sx={{ ml: 2 }}
                          />
                        </Box>
                      }
                    />
                  </ListItem>
                </React.Fragment>
              ))}
            </List>
          </Paper>
        </>
      )}
    </Box>
  );
};

export default PlaylistCalculator;