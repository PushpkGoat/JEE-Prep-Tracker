import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Checkbox,
  IconButton,
  TextField,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Card,
  CardContent,
  LinearProgress,
  Chip,
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  ExpandMore as ExpandMoreIcon,
  Flag as FlagIcon,
  AccessTime as AccessTimeIcon,
  CalendarToday as CalendarIcon,
} from '@mui/icons-material';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

// Define interfaces
interface Topic {
  id: string;
  name: string;
  completed: boolean;
  priority: 'High' | 'Medium' | 'Low';
  studyTimeMinutes: number;
  lastRevisionDate: string | null;
  nextRevisionDate: string | null;
  notes: string;
}

interface Subject {
  id: string;
  name: string;
  topics: Topic[];
}

interface Grade {
  id: string;
  name: string;
  subjects: Subject[];
}

const StudyPlanner: React.FC = () => {
  const [grades, setGrades] = useState<Grade[]>([
    {
      id: 'grade-11',
      name: '11th Grade',
      subjects: [
        {
          id: 'subject-physics-11',
          name: 'Physics',
          topics: [
            {
              id: 'topic-1',
              name: 'Kinematics',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-2',
              name: 'Laws of Motion',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-3',
              name: 'Work, Energy and Power',
              completed: false,
              priority: 'Medium',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            }
          ]
        },
        {
          id: 'subject-chemistry-11',
          name: 'Chemistry',
          topics: [
            {
              id: 'topic-4',
              name: 'Some Basic Concepts of Chemistry',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-5',
              name: 'Structure of Atom',
              completed: false,
              priority: 'Medium',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            }
          ]
        },
        {
          id: 'subject-math-11',
          name: 'Mathematics',
          topics: [
            {
              id: 'topic-6',
              name: 'Sets and Functions',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-7',
              name: 'Trigonometric Functions',
              completed: false,
              priority: 'Medium',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            }
          ]
        }
      ]
    },
    {
      id: 'grade-12',
      name: '12th Grade',
      subjects: [
        {
          id: 'subject-physics-12',
          name: 'Physics',
          topics: [
            {
              id: 'topic-8',
              name: 'Electrostatics',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-9',
              name: 'Current Electricity',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            }
          ]
        },
        {
          id: 'subject-chemistry-12',
          name: 'Chemistry',
          topics: [
            {
              id: 'topic-10',
              name: 'Solid State',
              completed: false,
              priority: 'Medium',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-11',
              name: 'Solutions',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            }
          ]
        },
        {
          id: 'subject-math-12',
          name: 'Mathematics',
          topics: [
            {
              id: 'topic-12',
              name: 'Relations and Functions',
              completed: false,
              priority: 'Medium',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            },
            {
              id: 'topic-13',
              name: 'Matrices',
              completed: false,
              priority: 'High',
              studyTimeMinutes: 0,
              lastRevisionDate: null,
              nextRevisionDate: null,
              notes: ''
            }
          ]
        }
      ]
    }
  ]);

  const [currentGradeIndex, setCurrentGradeIndex] = useState(0);
  const [currentSubjectIndex, setCurrentSubjectIndex] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTopic, setEditingTopic] = useState<Topic | null>(null);
  const [newTopicName, setNewTopicName] = useState('');
  const [newTopicPriority, setNewTopicPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [studyTimeDialogOpen, setStudyTimeDialogOpen] = useState(false);
  const [studyTimeMinutes, setStudyTimeMinutes] = useState(0);
  const [currentTopicId, setCurrentTopicId] = useState<string | null>(null);

  // Load data from storage on component mount
  useEffect(() => {
    const loadStudyPlan = async () => {
      try {
        // In a real app, this would call the Electron backend
        // For now, we'll use the default state
        // const studyPlan = await window.electron.ipcRenderer.invoke('get-study-plan');
        // if (studyPlan && studyPlan.grades) {
        //   setGrades(studyPlan.grades);
        // }
      } catch (error) {
        console.error('Failed to load study plan:', error);
      }
    };

    loadStudyPlan();
  }, []);

  // Save data to storage when it changes
  useEffect(() => {
    const saveStudyPlan = async () => {
      try {
        // In a real app, this would call the Electron backend
        // await window.electron.ipcRenderer.invoke('save-study-plan', { grades });
      } catch (error) {
        console.error('Failed to save study plan:', error);
      }
    };

    saveStudyPlan();
  }, [grades]);

  const handleGradeChange = (event: React.SyntheticEvent, newValue: number) => {
    setCurrentGradeIndex(newValue);
    setCurrentSubjectIndex(0);
  };

  const handleSubjectChange = (event: React.SyntheticEvent, newValue: number) => {
    setCurrentSubjectIndex(newValue);
  };

  const handleTopicCheck = (topicId: string) => {
    setGrades(prevGrades => {
      const newGrades = [...prevGrades];
      const grade = newGrades[currentGradeIndex];
      const subject = grade.subjects[currentSubjectIndex];
      const topicIndex = subject.topics.findIndex(t => t.id === topicId);
      
      if (topicIndex !== -1) {
        const newTopics = [...subject.topics];
        newTopics[topicIndex] = {
          ...newTopics[topicIndex],
          completed: !newTopics[topicIndex].completed,
          lastRevisionDate: new Date().toISOString().split('T')[0]
        };
        
        // Calculate next revision date (7 days later)
        if (!newTopics[topicIndex].completed) {
          const nextDate = new Date();
          nextDate.setDate(nextDate.getDate() + 7);
          newTopics[topicIndex].nextRevisionDate = nextDate.toISOString().split('T')[0];
        }
        
        subject.topics = newTopics;
      }
      
      return newGrades;
    });
  };

  const handleAddTopic = () => {
    setEditingTopic(null);
    setNewTopicName('');
    setNewTopicPriority('Medium');
    setDialogOpen(true);
  };

  const handleEditTopic = (topic: Topic) => {
    setEditingTopic(topic);
    setNewTopicName(topic.name);
    setNewTopicPriority(topic.priority);
    setDialogOpen(true);
  };

  const handleDeleteTopic = (topicId: string) => {
    setGrades(prevGrades => {
      const newGrades = [...prevGrades];
      const grade = newGrades[currentGradeIndex];
      const subject = grade.subjects[currentSubjectIndex];
      subject.topics = subject.topics.filter(t => t.id !== topicId);
      return newGrades;
    });
  };

  const handleSaveTopic = () => {
    if (!newTopicName.trim()) {
      return;
    }

    setGrades(prevGrades => {
      const newGrades = [...prevGrades];
      const grade = newGrades[currentGradeIndex];
      const subject = grade.subjects[currentSubjectIndex];

      if (editingTopic) {
        // Edit existing topic
        const topicIndex = subject.topics.findIndex(t => t.id === editingTopic.id);
        if (topicIndex !== -1) {
          subject.topics[topicIndex] = {
            ...subject.topics[topicIndex],
            name: newTopicName,
            priority: newTopicPriority
          };
        }
      } else {
        // Add new topic
        const newTopic: Topic = {
          id: `topic-${Date.now()}`,
          name: newTopicName,
          completed: false,
          priority: newTopicPriority,
          studyTimeMinutes: 0,
          lastRevisionDate: null,
          nextRevisionDate: null,
          notes: ''
        };
        subject.topics.push(newTopic);
      }

      return newGrades;
    });

    setDialogOpen(false);
  };

  const handleOpenStudyTimeDialog = (topicId: string) => {
    setCurrentTopicId(topicId);
    setStudyTimeMinutes(0);
    setStudyTimeDialogOpen(true);
  };

  const handleSaveStudyTime = () => {
    if (!currentTopicId || studyTimeMinutes <= 0) {
      setStudyTimeDialogOpen(false);
      return;
    }

    setGrades(prevGrades => {
      const newGrades = [...prevGrades];
      const grade = newGrades[currentGradeIndex];
      const subject = grade.subjects[currentSubjectIndex];
      const topicIndex = subject.topics.findIndex(t => t.id === currentTopicId);
      
      if (topicIndex !== -1) {
        subject.topics[topicIndex] = {
          ...subject.topics[topicIndex],
          studyTimeMinutes: subject.topics[topicIndex].studyTimeMinutes + studyTimeMinutes,
          lastRevisionDate: new Date().toISOString().split('T')[0]
        };
        
        // Calculate next revision date (7 days later)
        const nextDate = new Date();
        nextDate.setDate(nextDate.getDate() + 7);
        subject.topics[topicIndex].nextRevisionDate = nextDate.toISOString().split('T')[0];
      }
      
      return newGrades;
    });

    setStudyTimeDialogOpen(false);
  };

  // Calculate progress statistics
  const getProgressStats = () => {
    const currentGrade = grades[currentGradeIndex];
    const totalTopics = currentGrade.subjects.reduce((sum, subject) => sum + subject.topics.length, 0);
    const completedTopics = currentGrade.subjects.reduce(
      (sum, subject) => sum + subject.topics.filter(t => t.completed).length, 
      0
    );
    
    const progressPercentage = totalTopics > 0 ? (completedTopics / totalTopics) * 100 : 0;
    
    return {
      totalTopics,
      completedTopics,
      progressPercentage
    };
  };

  // Get topics due for revision
  const getTopicsDueForRevision = () => {
    const today = new Date().toISOString().split('T')[0];
    const dueTopics: {topic: Topic, subject: string}[] = [];
    
    grades.forEach(grade => {
      grade.subjects.forEach(subject => {
        subject.topics.forEach(topic => {
          if (topic.nextRevisionDate && topic.nextRevisionDate <= today) {
            dueTopics.push({topic, subject: subject.name});
          }
        });
      });
    });
    
    return dueTopics;
  };

  // Prepare chart data for subject progress
  const getSubjectProgressData = () => {
    const currentGrade = grades[currentGradeIndex];
    
    return {
      labels: currentGrade.subjects.map(subject => subject.name),
      datasets: [
        {
          label: 'Completed',
          data: currentGrade.subjects.map(subject => {
            const total = subject.topics.length;
            const completed = subject.topics.filter(t => t.completed).length;
            return total > 0 ? (completed / total) * 100 : 0;
          }),
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
        },
      ],
    };
  };

  // Prepare chart data for priority distribution
  const getPriorityDistributionData = () => {
    const currentGrade = grades[currentGradeIndex];
    const priorities: {[key: string]: number} = {
      'High': 0,
      'Medium': 0,
      'Low': 0
    };
    
    currentGrade.subjects.forEach(subject => {
      subject.topics.forEach(topic => {
        priorities[topic.priority]++;
      });
    });
    
    return {
      labels: Object.keys(priorities),
      datasets: [
        {
          data: Object.values(priorities),
          backgroundColor: [
            'rgba(255, 99, 132, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(54, 162, 235, 0.6)',
          ],
          borderWidth: 1,
        },
      ],
    };
  };

  const stats = getProgressStats();
  const dueTopics = getTopicsDueForRevision();

  return (
    <Box>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Tabs value={currentGradeIndex} onChange={handleGradeChange} sx={{ mb: 2 }}>
              {grades.map((grade, index) => (
                <Tab key={grade.id} label={grade.name} value={index} />
              ))}
            </Tabs>
            
            <Tabs value={currentSubjectIndex} onChange={handleSubjectChange} sx={{ mb: 3 }}>
              {grades[currentGradeIndex].subjects.map((subject, index) => (
                <Tab key={subject.id} label={subject.name} value={index} />
              ))}
            </Tabs>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Topics
              </Typography>
              <Button 
                variant="contained" 
                startIcon={<AddIcon />}
                onClick={handleAddTopic}
              >
                Add Topic
              </Button>
            </Box>
            
            <List>
              {grades[currentGradeIndex].subjects[currentSubjectIndex].topics.map((topic) => (
                <Accordion key={topic.id} sx={{ mb: 1 }}>
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                      <Checkbox
                        checked={topic.completed}
                        onChange={() => handleTopicCheck(topic.id)}
                        onClick={(e) => e.stopPropagation()}
                      />
                      <Typography 
                        sx={{ 
                          flexGrow: 1,
                          textDecoration: topic.completed ? 'line-through' : 'none',
                          opacity: topic.completed ? 0.7 : 1
                        }}
                      >
                        {topic.name}
                      </Typography>
                      <Chip 
                        label={topic.priority} 
                        size="small"
                        color={
                          topic.priority === 'High' ? 'error' : 
                          topic.priority === 'Medium' ? 'warning' : 
                          'info'
                        }
                        sx={{ mr: 1 }}
                      />
                    </Box>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Box>
                      <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                        <AccessTimeIcon fontSize="small" sx={{ verticalAlign: 'middle', mr: 1 }} />
                        Total study time: {Math.floor(topic.studyTimeMinutes / 60)}h {topic.studyTimeMinutes % 60}m
                      </Typography>
                      
                      {topic.lastRevisionDate && (
                        <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                          <CalendarIcon fontSize="small" sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Last revised: {topic.lastRevisionDate}
                        </Typography>
                      )}
                      
                      {topic.nextRevisionDate && (
                        <Typography 
                          variant="body2" 
                          color={
                            new Date(topic.nextRevisionDate) <= new Date() ? 
                            'error' : 'textSecondary'
                          }
                          sx={{ mb: 2 }}
                        >
                          <CalendarIcon fontSize="small" sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Next revision: {topic.nextRevisionDate}
                        </Typography>
                      )}
                      
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <Button 
                          variant="outlined" 
                          size="small"
                          startIcon={<AccessTimeIcon />}
                          onClick={() => handleOpenStudyTimeDialog(topic.id)}
                        >
                          Log Study Time
                        </Button>
                        <Button 
                          variant="outlined" 
                          size="small"
                          startIcon={<EditIcon />}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditTopic(topic);
                          }}
                        >
                          Edit
                        </Button>
                        <Button 
                          variant="outlined" 
                          size="small"
                          color="error"
                          startIcon={<DeleteIcon />}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteTopic(topic.id);
                          }}
                        >
                          Delete
                        </Button>
                      </Box>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              ))}
              
              {grades[currentGradeIndex].subjects[currentSubjectIndex].topics.length === 0 && (
                <Typography variant="body1" color="textSecondary" sx={{ textAlign: 'center', py: 3 }}>
                  No topics added yet. Click "Add Topic" to get started.
                </Typography>
              )}
            </List>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Card elevation={3} sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Progress Overview
              </Typography>
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" color="textSecondary" gutterBottom>
                  {stats.completedTopics} of {stats.totalTopics} topics completed
                </Typography>
                <LinearProgress 
                  variant="determinate" 
                  value={stats.progressPercentage} 
                  sx={{ height: 10, borderRadius: 5 }}
                />
              </Box>
              <Typography variant="h4" align="center" sx={{ my: 2 }}>
                {Math.round(stats.progressPercentage)}%
              </Typography>
            </CardContent>
          </Card>
          
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Subject Progress
            </Typography>
            <Box sx={{ height: 200 }}>
              <Bar 
                data={getSubjectProgressData()} 
                options={{ 
                  maintainAspectRatio: false,
                  scales: {
                    y: {
                      beginAtZero: true,
                      max: 100,
                      title: {
                        display: true,
                        text: 'Completion %'
                      }
                    }
                  }
                }} 
              />
            </Box>
          </Paper>
          
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Priority Distribution
            </Typography>
            <Box sx={{ height: 200 }}>
              <Pie 
                data={getPriorityDistributionData()} 
                options={{ maintainAspectRatio: false }} 
              />
            </Box>
          </Paper>
          
          <Paper elevation={3} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Due for Revision
            </Typography>
            {dueTopics.length > 0 ? (
              <List dense>
                {dueTopics.map((item, index) => (
                  <ListItem key={index} sx={{ py: 0.5 }}>
                    <ListItemIcon sx={{ minWidth: 36 }}>
                      <FlagIcon color="error" fontSize="small" />
                    </ListItemIcon>
                    <ListItemText 
                      primary={item.topic.name} 
                      secondary={item.subject}
                    />
                  </ListItem>
                ))}
              </List>
            ) : (
              <Typography variant="body2" color="textSecondary" sx={{ textAlign: 'center', py: 2 }}>
                No topics due for revision.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
      
      {/* Add/Edit Topic Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>{editingTopic ? 'Edit Topic' : 'Add New Topic'}</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Topic Name"
            fullWidth
            value={newTopicName}
            onChange={(e) => setNewTopicName(e.target.value)}
            sx={{ mb: 2 }}
          />
          <FormControl fullWidth>
            <InputLabel>Priority</InputLabel>
            <Select
              value={newTopicPriority}
              label="Priority"
              onChange={(e) => setNewTopicPriority(e.target.value as 'High' | 'Medium' | 'Low')}
            >
              <MenuItem value="High">High</MenuItem>
              <MenuItem value="Medium">Medium</MenuItem>
              <MenuItem value="Low">Low</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveTopic} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
      
      {/* Log Study Time Dialog */}
      <Dialog open={studyTimeDialogOpen} onClose={() => setStudyTimeDialogOpen(false)}>
        <DialogTitle>Log Study Time</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Minutes"
            type="number"
            fullWidth
            value={studyTimeMinutes}
            onChange={(e) => setStudyTimeMinutes(parseInt(e.target.value) || 0)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setStudyTimeDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveStudyTime} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default StudyPlanner;