import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Switch,
  FormControlLabel,
  Divider,
  Slider,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Snackbar,
  Tooltip,
  ListItemIcon,
} from '@mui/material';
import {
  Save as SaveIcon,
  Folder as FolderIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Refresh as RefreshIcon,
  VpnKey as VpnKeyIcon,
} from '@mui/icons-material';

// Define interfaces
interface Proxy {
  id: string;
  name: string;
  url: string;
  type: 'http' | 'https' | 'socks';
  status: 'active' | 'inactive' | 'error';
}

interface Settings {
  ipRotation: {
    enabled: boolean;
    interval: number;
    proxyList: Proxy[];
  };
  downloadPath: string;
  playbackSettings: {
    defaultSpeed: number;
    defaultVolume: number;
  };
}

const Settings: React.FC = () => {
  const [settings, setSettings] = useState<Settings>({
    ipRotation: {
      enabled: true,
      interval: 10,
      proxyList: []
    },
    downloadPath: '',
    playbackSettings: {
      defaultSpeed: 1,
      defaultVolume: 0.5
    }
  });
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProxy, setEditingProxy] = useState<Proxy | null>(null);
  const [newProxyName, setNewProxyName] = useState('');
  const [newProxyUrl, setNewProxyUrl] = useState('');
  const [newProxyType, setNewProxyType] = useState<'http' | 'https' | 'socks'>('https');
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  // Load settings on component mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        // In a real app, this would call the Electron backend
        if (window.electron) {
          const appSettings = await window.electron.ipcRenderer.invoke('get-settings');
          setSettings(appSettings);
        }
      } catch (error) {
        console.error('Failed to load settings:', error);
      }
    };

    loadSettings();
  }, []);

  // Save settings
  const saveSettings = async () => {
    try {
      // In a real app, this would call the Electron backend
      if (window.electron) {
        await window.electron.ipcRenderer.invoke('update-settings', settings);
      }
      
      setSnackbarMessage('Settings saved successfully');
      setSnackbarOpen(true);
    } catch (error) {
      console.error('Failed to save settings:', error);
      
      setSnackbarMessage('Failed to save settings');
      setSnackbarOpen(true);
    }
  };

  // Select download directory
  const selectDownloadDirectory = async () => {
    try {
      if (window.electron) {
        const result = await window.electron.ipcRenderer.invoke('select-download-directory');
        
        if (result.success) {
          setSettings({
            ...settings,
            downloadPath: result.path
          });
          
          setSnackbarMessage(`Download directory set to: ${result.path}`);
          setSnackbarOpen(true);
        }
      }
    } catch (error) {
      console.error('Failed to select download directory:', error);
    }
  };

  // Open add/edit proxy dialog
  const handleOpenDialog = (proxy?: Proxy) => {
    if (proxy) {
      setEditingProxy(proxy);
      setNewProxyName(proxy.name);
      setNewProxyUrl(proxy.url);
      setNewProxyType(proxy.type);
    } else {
      setEditingProxy(null);
      setNewProxyName('');
      setNewProxyUrl('');
      setNewProxyType('https');
    }
    
    setDialogOpen(true);
  };

  // Save proxy
  const handleSaveProxy = () => {
    if (!newProxyName.trim() || !newProxyUrl.trim()) {
      return;
    }

    if (editingProxy) {
      // Edit existing proxy
      setSettings({
        ...settings,
        ipRotation: {
          ...settings.ipRotation,
          proxyList: settings.ipRotation.proxyList.map(proxy => 
            proxy.id === editingProxy.id 
              ? { 
                  ...proxy, 
                  name: newProxyName,
                  url: newProxyUrl,
                  type: newProxyType
                } 
              : proxy
          )
        }
      });
    } else {
      // Add new proxy
      const newProxy: Proxy = {
        id: `proxy-${Date.now()}`,
        name: newProxyName,
        url: newProxyUrl,
        type: newProxyType,
        status: 'inactive'
      };
      
      setSettings({
        ...settings,
        ipRotation: {
          ...settings.ipRotation,
          proxyList: [...settings.ipRotation.proxyList, newProxy]
        }
      });
    }

    setDialogOpen(false);
  };

  // Delete proxy
  const handleDeleteProxy = (proxyId: string) => {
    setSettings({
      ...settings,
      ipRotation: {
        ...settings.ipRotation,
        proxyList: settings.ipRotation.proxyList.filter(proxy => proxy.id !== proxyId)
      }
    });
  };

  // Rotate IP manually
  const rotateIp = async () => {
    try {
      if (window.electron) {
        const result = await window.electron.ipcRenderer.invoke('rotate-ip');
        
        if (result.success) {
          setSnackbarMessage('IP address rotated manually');
          setSnackbarOpen(true);
        } else {
          setSnackbarMessage(`Failed to rotate IP: ${result.message}`);
          setSnackbarOpen(true);
        }
      }
    } catch (error: any) {
      console.error('Failed to rotate IP:', error);
      setSnackbarMessage(`Error: ${error.message}`);
      setSnackbarOpen(true);
    }
  };

  return (
    <Box>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Download Settings
            </Typography>
            
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <TextField
                fullWidth
                variant="outlined"
                label="Download Directory"
                value={settings.downloadPath}
                disabled
              />
              <Button
                variant="outlined"
                onClick={selectDownloadDirectory}
                startIcon={<FolderIcon />}
              >
                Browse
              </Button>
            </Box>
            
            <Divider sx={{ my: 3 }} />
            
            <Typography variant="h6" gutterBottom>
              Playback Settings
            </Typography>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" gutterBottom>
                Default Playback Speed
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Slider
                  value={settings.playbackSettings.defaultSpeed}
                  min={0.25}
                  max={3}
                  step={0.25}
                  marks={[
                    { value: 0.5, label: '0.5x' },
                    { value: 1, label: '1x' },
                    { value: 1.5, label: '1.5x' },
                    { value: 2, label: '2x' },
                  ]}
                  onChange={(_, value) => setSettings({
                    ...settings,
                    playbackSettings: {
                      ...settings.playbackSettings,
                      defaultSpeed: value as number
                    }
                  })}
                  sx={{ flexGrow: 1 }}
                />
                <Typography variant="body2">
                  {settings.playbackSettings.defaultSpeed}x
                </Typography>
              </Box>
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" gutterBottom>
                Default Volume
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Slider
                  value={settings.playbackSettings.defaultVolume}
                  min={0}
                  max={1}
                  step={0.05}
                  marks={[
                    { value: 0, label: '0%' },
                    { value: 0.5, label: '50%' },
                    { value: 1, label: '100%' },
                  ]}
                  onChange={(_, value) => setSettings({
                    ...settings,
                    playbackSettings: {
                      ...settings.playbackSettings,
                      defaultVolume: value as number
                    }
                  })}
                  sx={{ flexGrow: 1 }}
                />
                <Typography variant="body2">
                  {Math.round(settings.playbackSettings.defaultVolume * 100)}%
                </Typography>
              </Box>
            </Box>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                IP Rotation Settings
              </Typography>
              <Tooltip title="Rotate IP Now">
                <IconButton onClick={rotateIp} color="primary">
                  <RefreshIcon />
                </IconButton>
              </Tooltip>
            </Box>
            
            <FormControlLabel
              control={
                <Switch 
                  checked={settings.ipRotation.enabled}
                  onChange={(e) => setSettings({
                    ...settings,
                    ipRotation: {
                      ...settings.ipRotation,
                      enabled: e.target.checked
                    }
                  })}
                />
              }
              label="Enable automatic IP rotation"
            />
            
            <Box sx={{ mt: 2, mb: 3 }}>
              <Typography variant="body2" gutterBottom>
                Rotation Interval (seconds)
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Slider
                  value={settings.ipRotation.interval}
                  min={5}
                  max={60}
                  step={5}
                  marks={[
                    { value: 10, label: '10s' },
                    { value: 30, label: '30s' },
                    { value: 60, label: '60s' },
                  ]}
                  onChange={(_, value) => setSettings({
                    ...settings,
                    ipRotation: {
                      ...settings.ipRotation,
                      interval: value as number
                    }
                  })}
                  sx={{ flexGrow: 1 }}
                  disabled={!settings.ipRotation.enabled}
                />
                <Typography variant="body2">
                  {settings.ipRotation.interval}s
                </Typography>
              </Box>
            </Box>
            
            <Box sx={{ mb: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="subtitle1">
                  Proxy List
                </Typography>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<AddIcon />}
                  onClick={() => handleOpenDialog()}
                >
                  Add Proxy
                </Button>
              </Box>
              
              <List>
                {settings.ipRotation.proxyList.map((proxy) => (
                  <ListItem key={proxy.id}>
                    <ListItemIcon>
                      <VpnKeyIcon />
                    </ListItemIcon>
                    <ListItemText
                      primary={proxy.name}
                      secondary={`${proxy.type.toUpperCase()}: ${proxy.url}`}
                    />
                    <ListItemSecondaryAction>
                      <IconButton edge="end" onClick={() => handleOpenDialog(proxy)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton edge="end" onClick={() => handleDeleteProxy(proxy.id)}>
                        <DeleteIcon />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
              
              {settings.ipRotation.proxyList.length === 0 && (
                <Box sx={{ p: 3, textAlign: 'center' }}>
                  <Typography variant="body2" color="textSecondary">
                    No proxies configured. Add a proxy to enable IP rotation.
                  </Typography>
                </Box>
              )}
              
              <Alert severity="info" sx={{ mt: 2 }}>
                <Typography variant="body2">
                  IP rotation helps prevent YouTube from blocking your downloads by changing your IP address automatically.
                </Typography>
              </Alert>
            </Box>
          </Paper>
          
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
            <Button
              variant="contained"
              color="primary"
              startIcon={<SaveIcon />}
              onClick={saveSettings}
              size="large"
            >
              Save All Settings
            </Button>
          </Box>
        </Grid>
      </Grid>
      
      {/* Add/Edit Proxy Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>{editingProxy ? 'Edit Proxy' : 'Add New Proxy'}</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Proxy Name"
            fullWidth
            value={newProxyName}
            onChange={(e) => setNewProxyName(e.target.value)}
            sx={{ mb: 2 }}
          />
          
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Proxy Type</InputLabel>
            <Select
              value={newProxyType}
              label="Proxy Type"
              onChange={(e) => setNewProxyType(e.target.value as 'http' | 'https' | 'socks')}
            >
              <MenuItem value="http">HTTP</MenuItem>
              <MenuItem value="https">HTTPS</MenuItem>
              <MenuItem value="socks">SOCKS</MenuItem>
            </Select>
          </FormControl>
          
          <TextField
            margin="dense"
            label="Proxy URL"
            fullWidth
            value={newProxyUrl}
            onChange={(e) => setNewProxyUrl(e.target.value)}
            placeholder={newProxyType === 'socks' ? 'socks5://hostname:port' : 'http://hostname:port'}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveProxy} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
      
      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
        message={snackbarMessage}
      />
    </Box>
  );
};

export default Settings;