const { app, BrowserWindow, ipcMain, dialog, screen, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const http = require('http');
const { SocksProxyAgent } = require('socks-proxy-agent');
const { HttpsProxyAgent } = require('https-proxy-agent');
const Store = require('electron-store');
const ytdl = require('ytdl-core');
const ytpl = require('ytpl');
const { exec } = require('child_process');

// Initialize store for app settings
const store = new Store({
  defaults: {
    ipRotation: {
      enabled: true,
      interval: 10,
      proxyList: []
    },
    downloadPath: app.getPath('downloads'),
    playbackSettings: {
      defaultSpeed: 1,
      defaultVolume: 0.5
    },
    studyPlanner: {
      subjects: []
    },
    videoLibrary: {
      categories: [],
      videos: []
    }
  }
});

// Keep a global reference of the window object to prevent garbage collection
let mainWindow;

// Track the current proxy being used
let currentProxyIndex = 0;
let proxyRotationInterval = null;

// Create the browser window
function createWindow() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;
  
  mainWindow = new BrowserWindow({
    width: Math.min(1400, width * 0.9),
    height: Math.min(900, height * 0.9),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../public/icon.ico'),
    backgroundColor: '#121212',
    show: false
  });

  // Load the app
  if (app.isPackaged) {
    // Production mode
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  } else {
    // Development mode
    mainWindow.loadURL('http://localhost:5173');
    // Open DevTools in development
    mainWindow.webContents.openDevTools();
  }

  // Show window when ready to prevent flickering
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Handle window closed
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Create window when Electron is ready
app.whenReady().then(() => {
  createWindow();

  // Start proxy rotation if enabled
  const ipRotationSettings = store.get('ipRotation');
  if (ipRotationSettings.enabled) {
    startProxyRotation(ipRotationSettings.interval);
  }

  // On macOS, recreate window when dock icon is clicked and no windows are open
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Quit when all windows are closed, except on macOS
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Handle IPC messages from renderer process

// Rotate IP address
ipcMain.handle('rotate-ip', async () => {
  try {
    await rotateProxy();
    return { success: true, message: 'IP rotated successfully' };
  } catch (error) {
    console.error('Error rotating IP:', error);
    return { success: false, message: error.message };
  }
});

// Fetch playlist info
ipcMain.handle('fetch-playlist', async (event, url) => {
  try {
    // Validate URL
    if (!ytdl.validateURL(url) && !ytpl.validateID(url)) {
      throw new Error('Invalid YouTube URL');
    }

    // Get playlist info
    let playlistInfo;
    
    if (ytpl.validateID(url)) {
      // It's a playlist
      playlistInfo = await ytpl(url);
      
      // Calculate total duration (this would require additional API calls in a real app)
      // For now, we'll use mock durations
      const videos = await Promise.all(playlistInfo.items.map(async (item, index) => {
        // In a real app, we would fetch video details to get duration
        // For now, we'll use a mock duration based on index
        const mockDuration = 180 + (index * 60); // 3 minutes + index * 1 minute
        
        return {
          id: item.id,
          title: item.title,
          thumbnail: item.thumbnails[0].url,
          duration: mockDuration,
          url: item.url,
          downloaded: false,
          downloadProgress: 0
        };
      }));
      
      return {
        id: playlistInfo.id,
        title: playlistInfo.title,
        videos: videos
      };
    } else {
      // It's a single video
      const videoInfo = await ytdl.getInfo(url);
      const video = {
        id: videoInfo.videoDetails.videoId,
        title: videoInfo.videoDetails.title,
        thumbnail: videoInfo.videoDetails.thumbnails[0].url,
        duration: parseInt(videoInfo.videoDetails.lengthSeconds),
        url: url,
        downloaded: false,
        downloadProgress: 0
      };
      
      return {
        id: 'single-' + video.id,
        title: 'Single Video',
        videos: [video]
      };
    }
  } catch (error) {
    console.error('Error fetching playlist:', error);
    throw error;
  }
});

// Download video
ipcMain.handle('download-video', async (event, { videoId, videoUrl, playlistId, quality, format }) => {
  try {
    // In a real implementation, this would download the video
    const downloadPath = store.get('downloadPath');
    const extension = format === 'audio' ? 'mp3' : 'mp4';
    const filePath = path.join(downloadPath, `video-${videoId}.${extension}`);
    
    // Simulate download progress
    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += 5;
      mainWindow.webContents.send('download-progress', { videoId, playlistId, progress });
      
      if (progress >= 100) {
        clearInterval(progressInterval);
        mainWindow.webContents.send('download-complete', { 
          videoId, 
          playlistId, 
          filePath 
        });
      }
    }, 500);
    
    return { success: true };
  } catch (error) {
    console.error('Error downloading video:', error);
    throw error;
  }
});

// Update settings
ipcMain.handle('update-settings', async (event, settings) => {
  try {
    // Update store with new settings
    store.set(settings);
    
    // Handle IP rotation settings change
    if (settings.ipRotation) {
      if (settings.ipRotation.enabled) {
        startProxyRotation(settings.ipRotation.interval);
      } else {
        stopProxyRotation();
      }
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error updating settings:', error);
    throw error;
  }
});

// Get settings
ipcMain.handle('get-settings', async () => {
  try {
    return store.store;
  } catch (error) {
    console.error('Error getting settings:', error);
    throw error;
  }
});

// Select download directory
ipcMain.handle('select-download-directory', async () => {
  try {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory']
    });
    
    if (!result.canceled && result.filePaths.length > 0) {
      const downloadPath = result.filePaths[0];
      store.set('downloadPath', downloadPath);
      return { success: true, path: downloadPath };
    }
    
    return { success: false };
  } catch (error) {
    console.error('Error selecting download directory:', error);
    throw error;
  }
});

// Enable Do Not Disturb mode
ipcMain.handle('enable-dnd', async () => {
  try {
    // This would use platform-specific APIs to enable Do Not Disturb
    // For Windows, we could use PowerShell commands
    if (process.platform === 'win32') {
      // This is a simplified example - actual implementation would be more complex
      exec('powershell -command "New-ItemProperty -Path HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings -Name NOC_GLOBAL_SETTING_ALLOW_TOASTS_ABOVE_LOCK -PropertyType DWORD -Value 0 -Force"');
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error enabling DND:', error);
    return { success: false, message: error.message };
  }
});

// Disable Do Not Disturb mode
ipcMain.handle('disable-dnd', async () => {
  try {
    // This would use platform-specific APIs to disable Do Not Disturb
    if (process.platform === 'win32') {
      // This is a simplified example - actual implementation would be more complex
      exec('powershell -command "New-ItemProperty -Path HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings -Name NOC_GLOBAL_SETTING_ALLOW_TOASTS_ABOVE_LOCK -PropertyType DWORD -Value 1 -Force"');
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error disabling DND:', error);
    return { success: false, message: error.message };
  }
});

// Open file in default application
ipcMain.handle('open-file', async (event, filePath) => {
  try {
    await shell.openPath(filePath);
    return { success: true };
  } catch (error) {
    console.error('Error opening file:', error);
    return { success: false, message: error.message };
  }
});

// Study planner functions
ipcMain.handle('save-study-plan', async (event, plan) => {
  try {
    store.set('studyPlanner', plan);
    return { success: true };
  } catch (error) {
    console.error('Error saving study plan:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('get-study-plan', async () => {
  try {
    return store.get('studyPlanner');
  } catch (error) {
    console.error('Error getting study plan:', error);
    throw error;
  }
});

// Video library functions
ipcMain.handle('save-video-library', async (event, library) => {
  try {
    store.set('videoLibrary', library);
    return { success: true };
  } catch (error) {
    console.error('Error saving video library:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('get-video-library', async () => {
  try {
    return store.get('videoLibrary');
  } catch (error) {
    console.error('Error getting video library:', error);
    throw error;
  }
});

// Proxy rotation functions

// Start proxy rotation
function startProxyRotation(interval) {
  // Clear existing interval if any
  if (proxyRotationInterval) {
    clearInterval(proxyRotationInterval);
  }
  
  // Set new interval
  proxyRotationInterval = setInterval(async () => {
    try {
      await rotateProxy();
      console.log('Proxy rotated automatically');
      mainWindow.webContents.send('proxy-rotated');
    } catch (error) {
      console.error('Error in automatic proxy rotation:', error);
    }
  }, interval * 1000);
}

// Stop proxy rotation
function stopProxyRotation() {
  if (proxyRotationInterval) {
    clearInterval(proxyRotationInterval);
    proxyRotationInterval = null;
  }
}

// Rotate to next proxy
async function rotateProxy() {
  try {
    // Get proxy list from settings
    const proxyList = store.get('ipRotation.proxyList');
    
    // If no proxies are configured, we'll simulate IP rotation
    // In a real app, you would use actual proxies or a VPN service
    if (!proxyList || proxyList.length === 0) {
      console.log('No proxies configured. Simulating IP rotation.');
      // In a real implementation, this would connect to a VPN or proxy service
      return;
    }
    
    // Move to next proxy in the list
    currentProxyIndex = (currentProxyIndex + 1) % proxyList.length;
    const proxy = proxyList[currentProxyIndex];
    
    // Apply proxy to global agent
    if (proxy.type === 'socks') {
      const socksAgent = new SocksProxyAgent(proxy.url);
      https.globalAgent = socksAgent;
      http.globalAgent = socksAgent;
    } else if (proxy.type === 'http' || proxy.type === 'https') {
      const httpsAgent = new HttpsProxyAgent(proxy.url);
      https.globalAgent = httpsAgent;
      http.globalAgent = httpsAgent;
    }
    
    console.log(`Rotated to proxy: ${proxy.name}`);
  } catch (error) {
    console.error('Error rotating proxy:', error);
    throw error;
  }
}