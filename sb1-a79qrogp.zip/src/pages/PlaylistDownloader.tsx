import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  IconButton,
  Divider,
  LinearProgress,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Grid,
  Card,
  CardContent,
  Switch,
  FormControlLabel,
  Tooltip,
  Alert,
  Snackbar,
} from '@mui/material';
import {
  Download as DownloadIcon,
  Folder as FolderIcon,
  Delete as DeleteIcon,
  PlayArrow as PlayIcon,
  Refresh as RefreshIcon,
  Check as CheckIcon,
  NetworkCheck as NetworkCheckIcon,
  VpnKey as VpnKeyIcon,
  Settings as SettingsIcon,
} from '@mui/icons-material';

// Define interfaces
interface Video {
  id: string;
  title: string;
  thumbnail: string;
  duration: number;
  url: string;
  downloaded: boolean;
  downloadProgress: number;
  filePath?: string;
}

interface Playlist {
  id: string;
  title: string;
  videos: Video[];
}

interface Proxy {
  id: string;
  name: string;
  url: string;
  type: 'http' | 'https' | 'socks';
  status: 'active' | 'inactive' | 'error';
}

const PlaylistDownloader: React.FC = () => {
  const [url, setUrl] = useState<string>('');
  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [downloadPath, setDownloadPath] = useState<string>('');
  const [ipRotationEnabled, setIpRotationEnabled] = useState<boolean>(true);
  const [ipRotationInterval, setIpRotationInterval] = useState<number>(10);
  const [proxyList, setProxyList] = useState<Proxy[]>([]);
  const [activeProxy, setActiveProxy] = useState<string | null>(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState<boolean>(false);
  const [selectedQuality, setSelectedQuality] = useState<string>('highest');
  const [selectedFormat, setSelectedFormat] = useState<string>('video');
  const [snackbarOpen, setSnackbarOpen] = useState<boolean>(false);
  const [snackbarMessage, setSnackbarMessage] = useState<string>('');
  const [lastIpRotation, setLastIpRotation] = useState<Date | null>(null);

  // Load settings on component mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        // In a real app, this would call the Electron backend
        if (window.electron) {
          const settings = await window.electron.ipcRenderer.invoke('get-settings');
          
          setDownloadPath(settings.downloadPath || '');
          setIpRotationEnabled(settings.ipRotation?.enabled ?? true);
          setIpRotationInterval(settings.ipRotation?.interval ?? 10);
          setProxyList(settings.ipRotation?.proxyList ?? []);
        }
      } catch (error) {
        console.error('Failed to load settings:', error);
      }
    };

    loadSettings();
  }, []);

  // Listen for IP rotation events
  useEffect(() => {
    const handleProxyRotated = () => {
      setLastIpRotation(new Date());
      setSnackbarMessage('IP address rotated successfully');
      setSnackbarOpen(true);
    };

    // In a real app, this would set up the event listener
    if (window.electron) {
      window.electron.ipcRenderer.on('proxy-rotated', handleProxyRotated);
    }

    return () => {
      // Clean up event listener
      if (window.electron) {
        window.electron.ipcRenderer.removeListener('proxy-rotated', handleProxyRotated);
      }
    };
  }, []);

  // Listen for download progress
  useEffect(() => {
    const handleDownloadProgress = (data: { videoId: string, playlistId: string, progress: number }) => {
      setPlaylist(prevPlaylist => {
        if (!prevPlaylist || prevPlaylist.id !== data.playlistId) return prevPlaylist;
        
        return {
          ...prevPlaylist,
          videos: prevPlaylist.videos.map(video => 
            video.id === data.videoId 
              ? { ...video, downloadProgress: data.progress } 
              : video
          )
        };
      });
    };

    const handleDownloadComplete = (data: { videoId: string, playlistId: string, filePath: string }) => {
      setPlaylist(prevPlaylist => {
        if (!prevPlaylist || prevPlaylist.id !== data.playlistId) return prevPlaylist;
        
        return {
          ...prevPlaylist,
          videos: prevPlaylist.videos.map(video => 
            video.id === data.videoId 
              ? { ...video, downloaded: true, downloadProgress: 100, filePath: data.filePath } 
              : video
          )
        };
      });

      setSnackbarMessage('Download completed');
      setSnackbarOpen(true);
    };

    // In a real app, this would set up the event listeners
    if (window.electron) {
      window.electron.ipcRenderer.on('download-progress', handleDownloadProgress);
      window.electron.ipcRenderer.on('download-complete', handleDownloadComplete);
    }

    return () => {
      // Clean up event listeners
      if (window.electron) {
        window.electron.ipcRenderer.removeListener('download-progress', handleDownloadProgress);
        window.electron.ipcRenderer.removeListener('download-complete', handleDownloadComplete);
      }
    };
  }, []);

  // Format seconds to HH:MM:SS
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return [
      hours > 0 ? String(hours).padStart(2, '0') : null,
      String(minutes).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].filter(Boolean).join(':');
  };

  // Calculate total duration
  const getTotalDuration = (): number => {
    if (!playlist) return 0;
    return playlist.videos.reduce((total, video) => total + video.duration, 0);
  };

  // Calculate total size (estimated)
  const getEstimatedSize = (): string => {
    if (!playlist) return '0 MB';
    
    // Rough estimate: 1 minute of video ≈ 10MB for medium quality
    const totalMinutes = getTotalDuration() / 60;
    const estimatedMB = totalMinutes * 10;
    
    if (estimatedMB > 1024) {
      return `${(estimatedMB / 1024).toFixed(2)} GB`;
    }
    
    return `${estimatedMB.toFixed(2)} MB`;
  };

  // Fetch playlist
  const fetchPlaylist = async () => {
    if (!url) {
      setError('Please enter a YouTube playlist URL');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Call Electron backend to fetch playlist
      if (window.electron) {
        const playlistData = await window.electron.ipcRenderer.invoke('fetch-playlist', url);
        setPlaylist(playlistData);
      } else {
        // Mock data for development without Electron
        const mockPlaylist: Playlist = {
          id: 'playlist-' + Date.now(),
          title: 'JEE Physics Complete Course',
          videos: Array(5).fill(null).map((_, i) => ({
            id: `video-${i}`,
            title: `${i+1}. ${['Mechanics', 'Electromagnetism', 'Optics', 'Modern Physics', 'Thermodynamics'][i % 5]} - Lecture ${Math.floor(i/5) + 1}`,
            thumbnail: `https://source.unsplash.com/random/300x200?science&sig=${i}`,
            duration: 600 + (i * 120), // 10 minutes + i * 2 minutes
            url: `https://youtube.com/watch?v=mock${i}`,
            downloaded: false,
            downloadProgress: 0
          }))
        };
        setPlaylist(mockPlaylist);
      }
      setLoading(false);
    } catch (err: any) {
      console.error('Failed to fetch playlist:', err);
      setError(err.message || 'Failed to fetch playlist. Please check the URL and try again.');
      setLoading(false);
    }
  };

  // Select download directory
  const selectDownloadDirectory = async () => {
    try {
      if (window.electron) {
        const result = await window.electron.ipcRenderer.invoke('select-download-directory');
        
        if (result.success) {
          setDownloadPath(result.path);
          setSnackbarMessage(`Download directory set to: ${result.path}`);
          setSnackbarOpen(true);
        }
      }
    } catch (error) {
      console.error('Failed to select download directory:', error);
    }
  };

  // Download video
  const downloadVideo = async (videoId: string, videoUrl: string) => {
    if (!playlist) return;
    
    try {
      if (window.electron) {
        await window.electron.ipcRenderer.invoke('download-video', {
          videoId,
          videoUrl,
          playlistId: playlist.id,
          quality: selectedQuality,
          format: selectedFormat
        });
      } else {
        // Mock download for development without Electron
        let progress = 0;
        const interval = setInterval(() => {
          progress += 5;
          setPlaylist(prevPlaylist => {
            if (!prevPlaylist) return null;
            return {
              ...prevPlaylist,
              videos: prevPlaylist.videos.map(video => 
                video.id === videoId 
                  ? { ...video, downloadProgress: progress } 
                  : video
              )
            };
          });
          
          if (progress >= 100) {
            clearInterval(interval);
            setPlaylist(prevPlaylist => {
              if (!prevPlaylist) return null;
              return {
                ...prevPlaylist,
                videos: prevPlaylist.videos.map(video => 
                  video.id === videoId 
                    ? { ...video, downloaded: true, downloadProgress: 100, filePath: `/mock/path/video-${videoId}.mp4` } 
                    : video
                )
              };
            });
            setSnackbarMessage('Download completed');
            setSnackbarOpen(true);
          }
        }, 300);
      }
    } catch (error) {
      console.error('Failed to download video:', error);
    }
  };

  // Download all videos
  const downloadAllVideos = async () => {
    if (!playlist) return;
    
    setConfirmDialogOpen(false);
    
    for (const video of playlist.videos) {
      if (!video.downloaded && video.downloadProgress === 0) {
        await downloadVideo(video.id, video.url);
        // Add a small delay between downloads to prevent overwhelming the system
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  };

  // Rotate IP manually
  const rotateIp = async () => {
    try {
      if (window.electron) {
        const result = await window.electron.ipcRenderer.invoke('rotate-ip');
        
        if (result.success) {
          setLastIpRotation(new Date());
          setSnackbarMessage('IP address rotated manually');
          setSnackbarOpen(true);
        } else {
          setSnackbarMessage(`Failed to rotate IP: ${result.message}`);
          setSnackbarOpen(true);
        }
      } else {
        // Mock IP rotation for development without Electron
        setLastIpRotation(new Date());
        setSnackbarMessage('IP address rotated manually (simulated)');
        setSnackbarOpen(true);
      }
    } catch (error: any) {
      console.error('Failed to rotate IP:', error);
      setSnackbarMessage(`Error: ${error.message}`);
      setSnackbarOpen(true);
    }
  };

  // Update IP rotation settings
  const updateIpRotationSettings = async () => {
    try {
      if (window.electron) {
        await window.electron.ipcRenderer.invoke('update-settings', {
          ipRotation: {
            enabled: ipRotationEnabled,
            interval: ipRotationInterval,
            proxyList: proxyList
          }
        });
      }
      
      setSnackbarMessage('IP rotation settings updated');
      setSnackbarOpen(true);
    } catch (error) {
      console.error('Failed to update IP rotation settings:', error);
    }
  };

  // Open file
  const openFile = async (filePath: string) => {
    try {
      if (window.electron) {
        await window.electron.ipcRenderer.invoke('open-file', filePath);
      }
    } catch (error) {
      console.error('Failed to open file:', error);
    }
  };

  // Calculate overall download progress
  const getOverallProgress = (): number => {
    if (!playlist || playlist.videos.length === 0) return 0;
    
    const totalProgress = playlist.videos.reduce((sum, video) => sum + video.downloadProgress, 0);
    return totalProgress / playlist.videos.length;
  };

  return (
    <Box>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              YouTube Playlist Downloader
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="https://www.youtube.com/playlist?list=..."
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                error={!!error}
                helperText={error}
              />
              <Button
                variant="contained"
                color="primary"
                onClick={fetchPlaylist}
                disabled={loading}
                startIcon={loading ? <CircularProgress size={20} /> : <DownloadIcon />}
              >
                {loading ? 'Loading...' : 'Fetch'}
              </Button>
            </Box>
            
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="Download directory"
                value={downloadPath}
                disabled
              />
              <Button
                variant="outlined"
                onClick={selectDownloadDirectory}
                startIcon={<FolderIcon />}
              >
                Browse
              </Button>
            </Box>
            
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <FormControl sx={{ minWidth: 120 }}>
                <InputLabel>Quality</InputLabel>
                <Select
                  value={selectedQuality}
                  label="Quality"
                  onChange={(e) => setSelectedQuality(e.target.value)}
                >
                  <MenuItem value="highest">Highest</MenuItem>
                  <MenuItem value="720p">720p</MenuItem>
                  <MenuItem value="480p">480p</MenuItem>
                  <MenuItem value="360p">360p</MenuItem>
                </Select>
              </FormControl>
              
              <FormControl sx={{ minWidth: 120 }}>
                <InputLabel>Format</InputLabel>
                <Select
                  value={selectedFormat}
                  label="Format"
                  onChange={(e) => setSelectedFormat(e.target.value)}
                >
                  <MenuItem value="video">Video (MP4)</MenuItem>
                  <MenuItem value="audio">Audio Only (MP3)</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </Paper>
          
          {playlist && (
            <Paper elevation={3} sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h6">
                  {playlist.title}
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<DownloadIcon />}
                  onClick={() => setConfirmDialogOpen(true)}
                >
                  Download All
                </Button>
              </Box>
              
              <Box sx={{ mb: 3 }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={4}>
                    <Card>
                      <CardContent>
                        <Typography variant="subtitle2" color="textSecondary" gutterBottom>
                          Videos
                        </Typography>
                        <Typography variant="h4">
                          {playlist.videos.length}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <Card>
                      <CardContent>
                        <Typography variant="subtitle2" color="textSecondary" gutterBottom>
                          Total Duration
                        </Typography>
                        <Typography variant="h4">
                          {formatDuration(getTotalDuration())}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <Card>
                      <CardContent>
                        <Typography variant="subtitle2" color="textSecondary" gutterBottom>
                          Estimated Size
                        </Typography>
                        <Typography variant="h4">
                          {getEstimatedSize()}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              </Box>
              
              {getOverallProgress() > 0 && (
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" gutterBottom>
                    Overall Progress: {Math.round(getOverallProgress())}%
                  </Typography>
                  <LinearProgress 
                    variant="determinate" 
                    value={getOverallProgress()} 
                    sx={{ height: 10, borderRadius: 5 }}
                  />
                </Box>
              )}
              
              <List>
                {playlist.videos.map((video) => (
                  <React.Fragment key={video.id}>
                    <ListItem>
                      <Box sx={{ display: 'flex', width: '100%', alignItems: 'center' }}>
                        <Box 
                          sx={{ 
                            width: 120, 
                            height: 68, 
                            mr: 2, 
                            position: 'relative',
                            borderRadius: 1,
                            overflow: 'hidden'
                          }}
                        >
                          <img 
                            src={video.thumbnail} 
                            alt={video.title}
                            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                          />
                        </Box>
                        
                        <Box sx={{ flexGrow: 1 }}>
                          <Typography variant="body1" noWrap>
                            {video.title}
                          </Typography>
                          <Typography variant="body2" color="textSecondary">
                            {formatDuration(video.duration)}
                          </Typography>
                          
                          {video.downloadProgress > 0 && video.downloadProgress < 100 && (
                            <Box sx={{ mt: 1 }}>
                              <LinearProgress 
                                variant="determinate" 
                                value={video.downloadProgress} 
                                sx={{ height: 5, borderRadius: 5 }}
                              />
                              <Typography variant="caption" color="textSecondary">
                                {Math.round(video.downloadProgress)}%
                              </Typography>
                            </Box>
                          )}
                          
                          {video.downloaded && (
                            <Chip 
                              icon={<CheckIcon />}
                              label="Downloaded" 
                              size="small" 
                              color="success"
                              sx={{ mt: 1 }}
                            />
                          )}
                        </Box>
                        
                        <Box>
                          {video.downloaded ? (
                            <Button
                              variant="outlined"
                              startIcon={<PlayIcon />}
                              onClick={() => video.filePath && openFile(video.filePath)}
                            >
                              Play
                            </Button>
                          ) : (
                            <Button
                              variant="contained"
                              startIcon={<DownloadIcon />}
                              onClick={() => downloadVideo(video.id, video.url)}
                              disabled={video.downloadProgress > 0 && video.downloadProgress < 100}
                            >
                              {video.downloadProgress > 0 && video.downloadProgress < 100 
                                ? 'Downloading...' 
                                : 'Download'}
                            </Button>
                          )}
                        </Box>
                      </Box>
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
            </Paper>
          )}
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                IP Rotation
              </Typography>
              <Tooltip title="Rotate IP Now">
                <IconButton onClick={rotateIp} color="primary">
                  <RefreshIcon />
                </IconButton>
              </Tooltip>
            </Box>
            
            <FormControlLabel
              control={
                <Switch 
                  checked={ipRotationEnabled}
                  onChange={(e) => setIpRotationEnabled(e.target.checked)}
                />
              }
              label="Enable automatic IP rotation"
            />
            
            <Box sx={{ mt: 2, mb: 3 }}>
              <Typography variant="body2" gutterBottom>
                Rotation Interval (seconds)
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Slider
                  value={ipRotationInterval}
                  min={5}
                  max={60}
                  step={5}
                  onChange={(_, value) => setIpRotationInterval(value as number)}
                  sx={{ flexGrow: 1 }}
                />
                <Typography variant="body2">
                  {ipRotationInterval}s
                </Typography>
              </Box>
            </Box>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="body2" color="textSecondary">
                {lastIpRotation 
                  ? `Last rotation: ${lastIpRotation.toLocaleTimeString()}` 
                  : 'No IP rotation yet'}
              </Typography>
              <Button 
                variant="outlined" 
                size="small"
                onClick={updateIpRotationSettings}
              >
                Save Settings
              </Button>
            </Box>
            
            <Alert severity="info" sx={{ mt: 2 }}>
              IP rotation helps prevent YouTube from blocking your downloads by changing your IP address automatically.
            </Alert>
          </Paper>
          
          <Paper elevation={3} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Proxy Settings
            </Typography>
            <Typography variant="body2" color="textSecondary" paragraph>
              In a real application, you would be able to add and configure proxies here. For this demo, we're simulating IP rotation.
            </Typography>
            
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 2 }}>
              <VpnKeyIcon sx={{ fontSize: 60, opacity: 0.7 }} />
            </Box>
            
            <Typography variant="body2" align="center" paragraph>
              IP rotation is {ipRotationEnabled ? 'enabled' : 'disabled'}.
              {ipRotationEnabled && ` Rotating every ${ipRotationInterval} seconds.`}
            </Typography>
            
            <Alert severity="success">
              <Typography variant="body2">
                Your downloads are protected from IP-based rate limiting.
              </Typography>
            </Alert>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Confirm Download Dialog */}
      <Dialog
        open={confirmDialogOpen}
        onClose={() => setConfirmDialogOpen(false)}
      >
        <DialogTitle>Download Entire Playlist?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You are about to download {playlist?.videos.length} videos from "{playlist?.title}".
            This will use approximately {getEstimatedSize()} of disk space.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialogOpen(false)}>Cancel</Button>
          <Button onClick={downloadAllVideos} variant="contained" color="primary">
            Download All
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
        message={snackbarMessage}
      />
    </Box>
  );
};

export default PlaylistDownloader;